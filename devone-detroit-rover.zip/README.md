# DevOne Detroit Rover
## Twitter API Interface

### Requirements
- Node (latest)
- Network connection
- Environment file `.env`

### Get started
- Install dependencies: `$ npm i`
- Add an image to root named `"image.png"`
- Run app: `$ node post`
- Overwrite new image with same name
- Repeat run: `$ node post`